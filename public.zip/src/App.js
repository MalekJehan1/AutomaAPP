import React from "react";

import Header from './Componentes/Header'
import Body from './Componentes/Body'
import Dados from './Componentes/Dados'

export default function App() {

  const auto = 'XD'
  const peixe = 'Brasil'

  return (
    <>
      <Header/>
      <Body/>
      <Dados canal ={auto} youtube={peixe} automa='Epson'/>
    </>
  )
}

