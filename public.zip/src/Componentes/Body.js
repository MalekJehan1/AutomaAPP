import React from "react";

export default function Body()
{
    return(
        <section>
            <h2>Relatório de impressoras</h2>
            <p>Automasul - T.I.</p>
        </section>
    )
}