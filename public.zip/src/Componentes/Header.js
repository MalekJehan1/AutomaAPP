import React from "react";

import Logo from './Imgs/Automasul_vert_SOLUÇAO.png'

export default function Header(){
    return(
        <header>
            <img src={Logo}/>
            <h1>Printers</h1>
        </header>
    )
}