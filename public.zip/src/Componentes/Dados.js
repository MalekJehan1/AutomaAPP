import React from "react";

export default function Dados(props){
    return(
        <section>
            <p>Impressora 2: {props.canal}</p>
            <p>Impressora 4: {props.youtube} </p>
            <p>Impressora 6: {props.automa}</p>
        </section>
    )
}